package com.sudev.app.myapplication;

import org.junit.Test;

import static org.junit.Assert.*;

/**
 * Created by telefonica on 26/04/2017.
 */
public class nivel1Test {
    @Test
    public void onCreate() throws Exception {

    }

}