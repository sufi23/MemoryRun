package com.sudev.app.myapplication;

import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.IdRes;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;

import static com.sudev.app.myapplication.R.layout.menu_niveles;

/**
 * Created by telefonica on 25/04/2017.
 */

public class menu_niveles extends AppCompatActivity {
    Button menu;
    Button boton;
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(menu_niveles);
        boton = (Button) findViewById(R.id.lvl1);
        boton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(menu_niveles.this, nivel1.class);
                startActivity(intent);
            }
        });

        menu = (Button) findViewById(R.id.btnMenu);
        menu.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(menu_niveles.this, MainActivity.class);
                startActivity(intent);
            }


        });


    }





}

