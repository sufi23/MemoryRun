package com.sudev.app.myapplication;

import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;
import android.graphics.*;

import android.os.Handler;
import java.util.Arrays;
import java.util.Collections;
import android.animation.ObjectAnimator;




/**
 * Created by telefonica on 26/04/2017.
 */

public class nivel1 extends AppCompatActivity {

    TextView tv_p1,tv_p2;
    ImageView iv_11,iv_12,iv_13,iv_14, iv_21,iv_22,iv_23,iv_24,iv_31,iv_32,iv_33,iv_34;
    Handler manejador = new Handler();
    //Creo el Array de imágenes:
    Integer [] ArrayImagenes = {101,102,103,104,105,106,201,202,203,204,205,206};
    //Imagenes actuales
    int image101,image102,image103,image104,image105,image106,image201,image202,image203,image204,image205,image206;


    //primera y segunda carta en ser pulsada:
    int primeraCarta, segundaCarta;
    int clickprimero, clicksegundo;
    int numerocarta = 1;

    int tiempo =5;
    int tiempoinicial= tiempo;

    int turno = 1;
    int puntuacionJugador = 0, puntuacionCpu = 0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.nivel1);

        tv_p1 = (TextView) findViewById(R.id.tv_1);
        tv_p2 = (TextView) findViewById(R.id.tv_2);
        final Thread t = new Thread(){
        @Override
            public void run(){
            while (tiempo!=1){
                try {
                    Thread.sleep(1000);
                    runOnUiThread(new Runnable() {
                        @Override
                        public void run() {
                           tiempo--;
                            tv_p2.setText(String.valueOf(tiempo));
                            if(tiempo ==0){
                                juegoAcabadoporTiempo();
                            }
                        }
                    });

                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
            }

        }

        };
        t.start();



        tv_p1.setText("Puntuación:");
        tv_p2.setText("Tiempo:"+tiempo);


        iv_11 = (ImageView) findViewById(R.id.iv_11);
        iv_12 = (ImageView) findViewById(R.id.iv_12);
        iv_13 = (ImageView) findViewById(R.id.iv_13);
        iv_14 = (ImageView) findViewById(R.id.iv_14);
        iv_21 = (ImageView) findViewById(R.id.iv_21);
        iv_22 = (ImageView) findViewById(R.id.iv_22);
        iv_23 = (ImageView) findViewById(R.id.iv_23);
        iv_24 = (ImageView) findViewById(R.id.iv_24);
        iv_31 = (ImageView) findViewById(R.id.iv_31);
        iv_32 = (ImageView) findViewById(R.id.iv_32);
        iv_33 = (ImageView) findViewById(R.id.iv_33);
        iv_34 = (ImageView) findViewById(R.id.iv_34);

        iv_11.setTag("0");
        iv_12.setTag("1");
        iv_13.setTag("2");
        iv_14.setTag("3");
        iv_21.setTag("4");
        iv_22.setTag("5");
        iv_23.setTag("6");
        iv_24.setTag("7");
        iv_31.setTag("8");
        iv_32.setTag("9");
        iv_33.setTag("10");
        iv_34.setTag("11");


        //Cargamos las imagenes de las cartas:
        CargaImagenes();

        //hace la mezcla de imagenes aleatoriamente, cogiendo el array como un listado:
        Collections.shuffle(Arrays.asList(ArrayImagenes));

        //Cambia el color del jugador 2:
        tv_p2.setTextColor(Color.GRAY);

        iv_11.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                ObjectAnimator flip = ObjectAnimator.ofFloat(iv_11, "rotationY", 0f, 360f);
                flip.setDuration(250);
                flip.start();
                iv_11.setSelected(true);
                int laCarta = Integer.parseInt((String) view.getTag());
                cambialo(iv_11, laCarta);

            }
        });
        iv_12.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                ObjectAnimator flip = ObjectAnimator.ofFloat(iv_12, "rotationY", 0f, 360f);
                flip.setDuration(250);
                flip.start();
                iv_12.setSelected(true);
                int laCarta = Integer.parseInt((String) view.getTag());
                cambialo(iv_12, laCarta);

            }
        });
        iv_13.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                ObjectAnimator flip = ObjectAnimator.ofFloat(iv_13, "rotationY", 0f, 360f);
                flip.setDuration(250);
                flip.start();
                iv_13.setSelected(true);
                int laCarta = Integer.parseInt((String) view.getTag());
                cambialo(iv_13, laCarta);

            }
        });
        iv_14.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                ObjectAnimator flip = ObjectAnimator.ofFloat(iv_14, "rotationY", 0f, 360f);
                flip.setDuration(250);
                flip.start();
                iv_14.setSelected(true);
                int laCarta = Integer.parseInt((String) view.getTag());
                cambialo(iv_14, laCarta);

            }
        });
        iv_21.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                ObjectAnimator flip = ObjectAnimator.ofFloat(iv_21, "rotationY", 0f, 360f);
                flip.setDuration(250);
                flip.start();
                iv_21.setSelected(true);
                int laCarta = Integer.parseInt((String) view.getTag());
                cambialo(iv_21, laCarta);

            }
        });
        iv_22.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                ObjectAnimator flip = ObjectAnimator.ofFloat(iv_22, "rotationY", 0f, 360f);
                flip.setDuration(250);
                flip.start();
                iv_22.setSelected(true);
                int laCarta = Integer.parseInt((String) view.getTag());
                cambialo(iv_22, laCarta);


            }
        });
        iv_23.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                ObjectAnimator flip = ObjectAnimator.ofFloat(iv_23, "rotationY", 0f, 360f);
                flip.setDuration(250);
                flip.start();
                iv_23.setSelected(true);
                int laCarta = Integer.parseInt((String) view.getTag());
                cambialo(iv_23, laCarta);

            }
        });
        iv_24.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View view) {
                ObjectAnimator flip = ObjectAnimator.ofFloat(iv_24, "rotationY", 0f, 360f);
                flip.setDuration(250);
                flip.start();
                iv_24.setSelected(true);
                int laCarta = Integer.parseInt((String) view.getTag());
                cambialo(iv_24, laCarta);

            }
        });
        iv_31.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                ObjectAnimator flip = ObjectAnimator.ofFloat(iv_31, "rotationY", 0f, 360f);
                flip.setDuration(250);
                flip.start();
                iv_31.setSelected(true);
                int laCarta = Integer.parseInt((String) view.getTag());
                cambialo(iv_31, laCarta);

            }
        });
        iv_32.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                ObjectAnimator flip = ObjectAnimator.ofFloat(iv_32, "rotationY", 0f, 360f);
                flip.setDuration(250);
                flip.start();
                iv_32.setSelected(true);
                int laCarta = Integer.parseInt((String) view.getTag());
                cambialo(iv_32, laCarta);


            }
        });
        iv_33.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                ObjectAnimator flip = ObjectAnimator.ofFloat(iv_33, "rotationY", 0f, 360f);
                flip.setDuration(250);
                flip.start();
                iv_33.setSelected(true);
                int laCarta = Integer.parseInt((String) view.getTag());
                cambialo(iv_33, laCarta);

            }
        });
        iv_34.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                ObjectAnimator flip = ObjectAnimator.ofFloat(iv_34, "rotationY", 0f, 360f);
                flip.setDuration(250);
                flip.start();
                iv_34.setSelected(true);
                int laCarta = Integer.parseInt((String) view.getTag());
                cambialo(iv_34, laCarta);

            }
        });
    }

    //Funcion encargada de cargar las imágenes:

    protected void CargaImagenes(){
        image101 = R.drawable.ic_image101;
        image102 = R.drawable.ic_image102;
        image103 = R.drawable.ic_image103;
        image104 = R.drawable.ic_image104;
        image105 = R.drawable.ic_image105;
        image106 = R.drawable.ic_image106;
        image201 = R.drawable.ic_image201;
        image202 = R.drawable.ic_image202;
        image203 = R.drawable.ic_image203;
        image204 = R.drawable.ic_image204;
        image205 = R.drawable.ic_image205;
        image206 = R.drawable.ic_image206;

    }
    //Función que establece las imagenes correctas a cada imageView:
    public void cambialo (ImageView iv, int carta) {
        if (ArrayImagenes[carta] == 101) {
            iv.setImageResource(image101);
        } else if (ArrayImagenes[carta] == 102) {
            iv.setImageResource(image102);
        } else if (ArrayImagenes[carta] == 103) {
            iv.setImageResource(image103);
        } else if (ArrayImagenes[carta] == 104) {
            iv.setImageResource(image104);
        }else if (ArrayImagenes[carta] == 105) {
            iv.setImageResource(image105);
        } else if (ArrayImagenes[carta] == 106) {
            iv.setImageResource(image106);
        } else if (ArrayImagenes[carta] == 201) {
            iv.setImageResource(image201);
        }else if (ArrayImagenes[carta] == 202) {
            iv.setImageResource(image202);
        }else if (ArrayImagenes[carta] == 203) {
            iv.setImageResource(image203);
        }else if (ArrayImagenes[carta] == 204) {
            iv.setImageResource(image204);
        }else if (ArrayImagenes[carta] == 205) {
            iv.setImageResource(image205);
        }else if (ArrayImagenes[carta] == 206) {
            iv.setImageResource(image206);
        }

        //comprueba que imagen a sido seleccionada y la guarda en una variable temporal:
        if (numerocarta == 1) {
            primeraCarta = ArrayImagenes[carta];
            if (primeraCarta > 200) {
                primeraCarta = primeraCarta - 100;
            }
            numerocarta = 2;
            clickprimero = carta;
            iv.setEnabled(false);
        } else if (numerocarta == 2) {
            segundaCarta = ArrayImagenes[carta];
            if (segundaCarta > 200) {
                segundaCarta = segundaCarta - 100;
            }
            numerocarta = 1;
            clicksegundo = carta;

            iv_11.setEnabled(false);
            iv_12.setEnabled(false);
            iv_13.setEnabled(false);
            iv_14.setEnabled(false);
            iv_21.setEnabled(false);
            iv_22.setEnabled(false);
            iv_23.setEnabled(false);
            iv_24.setEnabled(false);
            iv_31.setEnabled(false);
            iv_32.setEnabled(false);
            iv_33.setEnabled(false);
            iv_34.setEnabled(false);

            Handler handler = new Handler();
            handler.postDelayed(new Runnable() {
                @Override
                public void run() {
                    calcular();
                }
            },500);

        }
    }




    private void calcular() {
        //Si las imagenes son iguales las borra y añade un punto:
        if (primeraCarta == segundaCarta) {
            if (clickprimero == 0) {
                iv_11.setVisibility(View.GONE);
            } else if (clickprimero == 1) {
                iv_12.setVisibility(View.GONE);
            } else if (clickprimero == 2) {
                iv_13.setVisibility(View.GONE);
            } else if (clickprimero == 3) {
                iv_14.setVisibility(View.GONE);
            } else if (clickprimero == 4) {
                iv_21.setVisibility(View.GONE);
            } else if (clickprimero == 5) {
                iv_22.setVisibility(View.GONE);
            } else if (clickprimero == 6) {
                iv_23.setVisibility(View.GONE);
            }else if (clickprimero == 7) {
                iv_24.setVisibility(View.GONE);
            }else if (clickprimero == 8) {
                iv_31.setVisibility(View.GONE);
            } else if (clickprimero == 9) {
                iv_32.setVisibility(View.GONE);
            } else if (clickprimero == 10) {
                iv_33.setVisibility(View.GONE);
            }else if (clickprimero == 11) {
                iv_34.setVisibility(View.GONE);
            }

            if (clicksegundo == 0) {
                iv_11.setVisibility(View.GONE);
            } else if (clicksegundo == 1) {
                iv_12.setVisibility(View.GONE);
            } else if (clicksegundo == 2) {
                iv_13.setVisibility(View.GONE);
            }else if (clicksegundo == 3) {
                iv_14.setVisibility(View.GONE);
            }  else if (clicksegundo == 4) {
                iv_21.setVisibility(View.GONE);
            } else if (clicksegundo == 5) {
                iv_22.setVisibility(View.GONE);
            } else if (clicksegundo == 6) {
                iv_23.setVisibility(View.GONE);
            }else if (clicksegundo == 7) {
                iv_24.setVisibility(View.GONE);
            }else if (clicksegundo == 8) {
                iv_31.setVisibility(View.GONE);
            } else if (clicksegundo == 9) {
                iv_32.setVisibility(View.GONE);
            } else if (clicksegundo == 10) {
                iv_33.setVisibility(View.GONE);
            }else if (clicksegundo == 11) {
                iv_34.setVisibility(View.GONE);
            }

            //Añade la puntuación a cada jugador de la partida:
            if (turno == 1) {
                puntuacionJugador++;
                tv_p1.setText("Puntuación: "+ puntuacionJugador);
            }


        }
        //devolvemos las imagenes a su estado original si no encontramos la pareja aplicandole el giro sobre y:
        else {
            if(iv_11.isSelected()) {
                iv_11.setImageResource(R.drawable.ic_back);
            ObjectAnimator flip = ObjectAnimator.ofFloat(iv_11, "rotationY", 180f, 0f);
            flip.setDuration(250);
            flip.start();
            iv_11.setSelected(false);}
            if (iv_12.isSelected()){
            iv_12.setImageResource(R.drawable.ic_back);
            ObjectAnimator flip1 = ObjectAnimator.ofFloat(iv_12, "rotationY", 180f, 0f);
            flip1.setDuration(250);
            flip1.start();
                iv_12.setSelected(false);}
            if (iv_13.isSelected()){
            iv_13.setImageResource(R.drawable.ic_back);
            ObjectAnimator flip2 = ObjectAnimator.ofFloat(iv_13, "rotationY", 180f, 0f);
            flip2.setDuration(250);
            flip2.start();
                iv_13.setSelected(false);}
            if (iv_14.isSelected()){
            iv_14.setImageResource(R.drawable.ic_back);
            ObjectAnimator flip3 = ObjectAnimator.ofFloat(iv_14, "rotationY", 180f, 0f);
            flip3.setDuration(250);
            flip3.start();
                iv_14.setSelected(false);}
            if (iv_21.isSelected()){
            iv_21.setImageResource(R.drawable.ic_back);
            ObjectAnimator flip4 = ObjectAnimator.ofFloat(iv_21, "rotationY", 180f, 0f);
            flip4.setDuration(250);
            flip4.start();
                iv_21.setSelected(false);}
            if (iv_22.isSelected()){
            iv_22.setImageResource(R.drawable.ic_back);
            ObjectAnimator flip5 = ObjectAnimator.ofFloat(iv_22, "rotationY", 180f, 0f);
            flip5.setDuration(250);
            flip5.start();
                iv_22.setSelected(false);}
            if (iv_23.isSelected()){
            iv_23.setImageResource(R.drawable.ic_back);
            ObjectAnimator flip6 = ObjectAnimator.ofFloat(iv_23, "rotationY", 180f, 0f);
            flip6.setDuration(250);
            flip6.start();
                iv_23.setSelected(false);}
            if (iv_24.isSelected()){
            iv_24.setImageResource(R.drawable.ic_back);
            ObjectAnimator flip7 = ObjectAnimator.ofFloat(iv_24, "rotationY", 180f, 0f);
            flip7.setDuration(250);
            flip7.start();
                iv_24.setSelected(false);}
            if (iv_31.isSelected()){
            iv_31.setImageResource(R.drawable.ic_back);
            ObjectAnimator flip8 = ObjectAnimator.ofFloat(iv_31, "rotationY", 180f, 0f);
            flip8.setDuration(250);
            flip8.start();
                iv_31.setSelected(false);}
            if (iv_32.isSelected()){
            iv_32.setImageResource(R.drawable.ic_back);
            ObjectAnimator flip9 = ObjectAnimator.ofFloat(iv_32, "rotationY", 180f, 0f);
            flip9.setDuration(250);
            flip9.start();
                iv_32.setSelected(false);}
            if (iv_33.isSelected()){
            iv_33.setImageResource(R.drawable.ic_back);
            ObjectAnimator flip10 = ObjectAnimator.ofFloat(iv_33, "rotationY", 180f, 0f);
            flip10.setDuration(250);
            flip10.start();
                iv_33.setSelected(false);}
            if (iv_34.isSelected()){
            iv_34.setImageResource(R.drawable.ic_back);
            ObjectAnimator flip11 = ObjectAnimator.ofFloat(iv_34, "rotationY", 180f, 0f);
            flip11.setDuration(250);
            flip11.start();
                iv_34.setSelected(false);}




        }
        iv_11.setEnabled(true);
        iv_12.setEnabled(true);
        iv_13.setEnabled(true);
        iv_14.setEnabled(true);
        iv_21.setEnabled(true);
        iv_22.setEnabled(true);
        iv_23.setEnabled(true);
        iv_24.setEnabled(true);
        iv_31.setEnabled(true);
        iv_32.setEnabled(true);
        iv_33.setEnabled(true);
        iv_34.setEnabled(true);

        //Comprueba si el juego ha acabado:
        juegoAcabado();

    }

    private void juegoAcabado(){
        if (iv_11.getVisibility() == View.GONE &&
                iv_12.getVisibility() == View.GONE &&
                iv_13.getVisibility() == View.GONE &&
                iv_14.getVisibility() == View.GONE &&
                iv_21.getVisibility() == View.GONE &&
                iv_22.getVisibility() == View.GONE &&
                iv_23.getVisibility() == View.GONE &&
                iv_24.getVisibility() == View.GONE &&
                iv_31.getVisibility() == View.GONE &&
                iv_32.getVisibility() == View.GONE &&
                iv_33.getVisibility() == View.GONE &&
                iv_34.getVisibility() == View.GONE ){

            AlertDialog.Builder alertDialogBuilder = new AlertDialog.Builder(nivel1.this);
            alertDialogBuilder.setMessage("Juego finalizado!\nTu puntuación:"+ puntuacionJugador + "\nTiempo Utilizado:"+ (tiempoinicial-tiempo))
                    .setCancelable(false)
                    .setPositiveButton("Siguiente nivel", new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialogInterface, int i) {
                            Intent intent = new Intent(getApplicationContext(), nivel1.class);
                            startActivity(intent);
                            finish();

                        }
                    })
                    .setNegativeButton("Salir", new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialogInterface, int i) {
                            finish();
                        }
                    });
            AlertDialog alertDialog = alertDialogBuilder.create();
            alertDialog.show();



        }


    }
    //Si el marcador llega a cero el juego se acaba sin comprobar las casillas:
    private void juegoAcabadoporTiempo(){


            AlertDialog.Builder alertDialogBuilder = new AlertDialog.Builder(nivel1.this);
            alertDialogBuilder.setMessage("Se te acabó el tiempo!\nTu puntuación:"+ puntuacionJugador + "\nTiempo Utilizado:"+ (tiempoinicial-tiempo))
                    .setCancelable(false)
                    .setPositiveButton("Siguiente nivel", new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialogInterface, int i) {
                            Intent intent = new Intent(getApplicationContext(), nivel1.class);
                            startActivity(intent);
                            finish();

                        }
                    })
                    .setNegativeButton("Salir", new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialogInterface, int i) {
                            finish();

                        }
                    });


            AlertDialog alertDialog = alertDialogBuilder.create();
            alertDialog.show();



        }



}